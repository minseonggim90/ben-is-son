# Ben's Baby — deploy guide

Single-page React app. Outside claude.ai, the MLB StatsAPI works directly
from the browser, so the site runs the FULL v3 model: FIP, real expected
innings per starter, and live 3-day bullpen fatigue.

## Deploy to Vercel (about 5 minutes)
1. Push this folder to a GitHub repo (or drag-drop the folder at
   vercel.com/new).
2. Vercel auto-detects Vite. Accept the defaults and deploy.
3. In the Vercel project: Settings -> Environment Variables ->
   add `ANTHROPIC_API_KEY` (get one at console.anthropic.com).
   This powers `/api/bullpens` (live bullpen ERAs, cached 6h).
   Without it the site still works, using the built-in fallback table.
4. Redeploy. Done — the URL is your site.

## Run locally
    npm install
    npm run dev

(Local dev won't have /api/bullpens unless you use `vercel dev`;
the fallback table covers it.)
