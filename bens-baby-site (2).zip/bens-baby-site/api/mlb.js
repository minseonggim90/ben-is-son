// Serverless proxy for the MLB StatsAPI (statsapi.mlb.com sends no CORS
// headers, so browsers can't call it directly). The browser calls
// /api/mlb?u=<path under /api/v1/> and this forwards it server-side.
export default async function handler(req, res) {
  const u = String(req.query.u || "");
  // strict allowlist: path+query chars only, no protocol/host smuggling
  if (!u || u.includes("..") || u.includes("://") || !/^[\w/?&=,.%()\[\]-]+$/.test(u)) {
    res.status(400).json({ error: "bad path" });
    return;
  }
  try {
    const r = await fetch(`https://statsapi.mlb.com/api/v1/${u}`);
    const data = await r.json();
    res.setHeader("Cache-Control", "s-maxage=60, stale-while-revalidate=300");
    res.status(r.ok ? 200 : r.status).json(data);
  } catch (e) {
    res.status(502).json({ error: String(e.message || e) });
  }
}
