// Vercel serverless function: fetches current season bullpen ERAs via the
// Anthropic API using a server-side key, so the key never ships to browsers.
// Set ANTHROPIC_API_KEY in the Vercel project's Environment Variables.
export default async function handler(req, res) {
  try {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        messages: [
          {
            role: "user",
            content:
              'Search the web NOW for current MLB team bullpen ERA, all 30 teams (covers.com team bullpen ERA statistics has them) — one search, no preamble, nothing before or after the JSON. Output must be JSON only: {"Brewers":3.48,"Red Sox":3.07} style, short club name to season bullpen ERA, all 30 teams, no spaces. JSON only.',
          },
        ],
        tools: [{ type: "web_search_20250305", name: "web_search" }],
      }),
    });
    const data = await r.json();
    const text = (data.content || [])
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n")
      .replace(/```json|```/g, "")
      .trim();
    const start = text.indexOf("{");
    const parsed = JSON.parse(text.slice(start, text.lastIndexOf("}") + 1));
    res.setHeader("Cache-Control", "s-maxage=21600"); // cache 6h at the edge
    res.status(200).json(parsed);
  } catch (e) {
    res.status(502).json({ error: String(e.message || e) });
  }
}
