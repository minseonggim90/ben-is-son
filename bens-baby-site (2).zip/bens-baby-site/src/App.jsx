import { useState, useEffect, useCallback, useRef } from "react";

// ————————————————————————————————————————————————
// BEN'S BABY — five strongest model picks daily, v3 model.
// Data: MLB StatsAPI (primary, deterministic JSON) for slate,
// starters, FIP components, innings/start, and 3-day pen fatigue.
// Claude+web search only for season bullpen ERA (with fallback).
// ————————————————————————————————————————————————

const REGRESSION_GAMES = 70;
const LEAGUE_RATE = 4.1;
const RUNS_PER_WIN = 10.0;
const HFA_ODDS = 1.19;
const LOGODDS_PER_WIN = 4.0;
const DEFAULT_SP_IP = 5.5;
const FATIGUE_FREE_IP3 = 9.0;
const FATIGUE_RUNS_PER_IP = 0.12;
const FIP_CONSTANT = 3.1;
const POLL_MINUTES = 30;
const N_PICKS = 5;
const MLB = "https://statsapi.mlb.com/api/v1";

// StatsAPI has no CORS headers, so hosted deployments go through the
// /api/mlb serverless proxy; direct fetch is kept as a second attempt
// for environments where it happens to work.
async function mlbGet(pathAndQuery) {
  try {
    const r = await fetch(`/api/mlb?u=${encodeURIComponent(pathAndQuery)}`);
    if (r.ok) {
      const ct = r.headers.get("content-type") || "";
      if (ct.includes("json")) return await r.json();
    }
  } catch {}
  const r2 = await fetch(`${MLB}/${pathAndQuery}`);
  if (!r2.ok) throw new Error(`StatsAPI ${r2.status}`);
  return r2.json();
}

// Fallback season bullpen ERA (Jul 2026) — used until/unless live loads.
const FALLBACK_BULLPEN = {
  Athletics: 5.51, Royals: 5.3, Nationals: 5.01, Rockies: 4.93,
  Twins: 4.91, Reds: 4.69, Pirates: 4.5, Giants: 4.43, Phillies: 4.4,
  Angels: 4.39, Cardinals: 4.34, Rangers: 4.21, Astros: 4.15,
  Rays: 4.1, Orioles: 4.08, Diamondbacks: 4.01, Cubs: 4.01,
  Mets: 3.96, "White Sox": 3.94, Marlins: 3.87, "Blue Jays": 3.86,
  Tigers: 3.8, Dodgers: 3.79, Guardians: 3.75, Padres: 3.75,
  Mariners: 3.58, Brewers: 3.48, Braves: 3.26, "Red Sox": 3.07,
  Yankees: 3.01,
};

// ——— model v3 ———

const regressedWpct = (w, l) =>
  (w + 0.5 * REGRESSION_GAMES) / (w + l + REGRESSION_GAMES);

const log5 = (a, b) => (a * (1 - b)) / (a * (1 - b) + b * (1 - a));

const bullpenFor = (teamName, bpMap) => {
  const key = Object.keys(bpMap).find((k) =>
    teamName.toLowerCase().includes(k.toLowerCase())
  );
  return key ? bpMap[key] : LEAGUE_RATE;
};

function effectiveBpRate(side, bpMap) {
  let rate = bullpenFor(side.team, bpMap);
  if (side.penIp3 != null && side.penIp3 > FATIGUE_FREE_IP3) {
    rate += (side.penIp3 - FATIGUE_FREE_IP3) * FATIGUE_RUNS_PER_IP;
  }
  return rate;
}

function runsVsAvg(side, bpMap) {
  const spIp = Math.min(Math.max(side.spIp ?? DEFAULT_SP_IP, 0), 9);
  const spRate = side.rate ?? LEAGUE_RATE;
  return (
    ((spRate - LEAGUE_RATE) * spIp +
      (effectiveBpRate(side, bpMap) - LEAGUE_RATE) * (9 - spIp)) / 9
  );
}

function predictGame(g, bpMap) {
  const base = log5(
    regressedWpct(g.home.w, g.home.l),
    regressedWpct(g.away.w, g.away.l)
  );
  let logit = Math.log(base / (1 - base)) + Math.log(HFA_ODDS);
  const delta = runsVsAvg(g.away, bpMap) - runsVsAvg(g.home, bpMap);
  logit += (delta / RUNS_PER_WIN) * LOGODDS_PER_WIN;
  const pHome = 1 / (1 + Math.exp(-logit));
  const homeFav = pHome >= 0.5;
  return {
    ...g,
    pick: homeFav ? g.home : g.away,
    opp: homeFav ? g.away : g.home,
    prob: homeFav ? pHome : 1 - pHome,
    pickIsHome: homeFav,
    anyTBD: g.home.rate == null || g.away.rate == null,
  };
}

// ——— data: MLB StatsAPI ———

const ipToFloat = (ip) => {
  const [w, f] = String(ip ?? "0").split(".");
  return parseInt(w || "0", 10) + (parseInt(f || "0", 10) || 0) / 3;
};

function fipFrom(stat) {
  const ip = ipToFloat(stat.inningsPitched);
  if (!ip) return null;
  const fip =
    (13 * (stat.homeRuns ?? 0) +
      3 * ((stat.baseOnBalls ?? 0) + (stat.hitByPitch ?? 0)) -
      2 * (stat.strikeOuts ?? 0)) / ip + FIP_CONSTANT;
  return Math.min(Math.max(fip, 1.5), 8);
}

async function fetchSlateStatsApi() {
  const d = new Date();
  const dateStr = `${String(d.getMonth() + 1).padStart(2, "0")}/${String(
    d.getDate()
  ).padStart(2, "0")}/${d.getFullYear()}`;
  const sched = await mlbGet(
    `schedule?sportId=1&date=${dateStr}&hydrate=probablePitcher,team`
  );
  const rawGames = (sched.dates?.[0]?.games || []).filter(
    (g) => g.gameType === "R" || g.gameType === "P"
  );
  if (!rawGames.length) throw new Error("No MLB games found for today");

  const pitcherIds = [];
  for (const g of rawGames)
    for (const s of ["home", "away"]) {
      const pid = g.teams[s].probablePitcher?.id;
      if (pid) pitcherIds.push(pid);
    }

  const pitcherStats = {};
  if (pitcherIds.length) {
    const people = await mlbGet(
      `people?personIds=${pitcherIds.join(",")}` +
        `&hydrate=stats(group=[pitching],type=[season])`
    );
    for (const p of people.people || []) {
      const stat = p.stats?.[0]?.splits?.[0]?.stat;
      if (!stat) continue;
      const ip = ipToFloat(stat.inningsPitched);
      const gs = stat.gamesStarted ?? 0;
      pitcherStats[p.id] = {
        fip: fipFrom(stat),
        era: parseFloat(stat.era) || null,
        expIp: gs > 0 ? Math.min(Math.max(ip / gs, 2.5), 7) : 3,
      };
    }
  }

  return rawGames.map((g) => {
    const side = (s) => {
      const t = g.teams[s];
      const pp = t.probablePitcher;
      const st = pp ? pitcherStats[pp.id] : null;
      return {
        team: t.team.teamName || t.team.name,
        fullName: t.team.name,
        id: t.team.id,
        w: t.leagueRecord?.wins ?? 0,
        l: t.leagueRecord?.losses ?? 0,
        sp: pp ? pp.fullName.split(" ").slice(-1)[0] : "TBD",
        rate: st ? st.fip ?? st.era : null, // FIP preferred, ERA fallback
        spIp: st ? st.expIp : null,
        penIp3: null, // filled by fatigue fetch
      };
    };
    return { home: side("home"), away: side("away") };
  });
}

async function fetchFatigue(games) {
  const wanted = new Set();
  for (const g of games) {
    wanted.add(g.home.fullName);
    wanted.add(g.away.fullName);
  }
  const fmt = (d) =>
    `${String(d.getMonth() + 1).padStart(2, "0")}/${String(
      d.getDate()
    ).padStart(2, "0")}/${d.getFullYear()}`;
  const end = new Date(Date.now() - 86400000);
  const start = new Date(Date.now() - 3 * 86400000);
  const sched = await mlbGet(
    `schedule?sportId=1&startDate=${fmt(start)}&endDate=${fmt(end)}`
  );
  const pks = [];
  for (const day of sched.dates || [])
    for (const g of day.games || []) {
      if (g.status?.abstractGameState !== "Final") continue;
      if (
        wanted.has(g.teams.home.team.name) ||
        wanted.has(g.teams.away.team.name)
      )
        pks.push(g.gamePk);
    }
  const totals = {};
  const results = await Promise.allSettled(
    pks.map((pk) => mlbGet(`game/${pk}/boxscore`))
  );
  for (const r of results) {
    if (r.status !== "fulfilled") continue;
    for (const s of ["home", "away"]) {
      const side = r.value.teams?.[s];
      if (!side || !wanted.has(side.team?.name)) continue;
      const pitchers = side.pitchers || [];
      for (const pid of pitchers.slice(1)) {
        const st = side.players?.[`ID${pid}`]?.stats?.pitching;
        if (st?.inningsPitched != null) {
          totals[side.team.name] =
            (totals[side.team.name] || 0) + ipToFloat(st.inningsPitched);
        }
      }
    }
  }
  return totals; // { full team name: relief IP last 3 days }
}

// ——— data: Claude fallback / bullpen ERAs ———

async function askClaude(prompt) {
  let res;
  try {
    res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }],
        tools: [{ type: "web_search_20250305", name: "web_search" }],
      }),
    });
  } catch (e) {
    throw new Error(`Network error reaching the API (${e.message})`);
  }
  if (!res.ok) throw new Error(`API responded ${res.status}`);
  const data = await res.json();
  const text = (data.content || [])
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n")
    .replace(/```json|```/g, "")
    .trim();
  if (!text)
    throw new Error(
      `API returned no text (stop_reason: ${data.stop_reason || "unknown"})`
    );
  return text;
}

function parseJsonLoose(text) {
  const start = text.indexOf("{");
  if (start === -1) throw new Error("No JSON in response");
  try {
    return JSON.parse(text.slice(start, text.lastIndexOf("}") + 1));
  } catch {
    const cut = text.lastIndexOf("],");
    if (cut > start) {
      try {
        return JSON.parse(text.slice(start, cut + 1) + "]}");
      } catch {}
    }
    throw new Error("Could not parse JSON");
  }
}

const withRetry = async (fn, attempts = 3) => {
  let lastErr;
  for (let i = 0; i < attempts; i++) {
    try {
      return await fn();
    } catch (e) {
      lastErr = e;
      await new Promise((r) => setTimeout(r, 2000 * (i + 1)));
    }
  }
  throw lastErr;
};

async function fetchSlateClaude() {
  const today = new Date().toLocaleDateString("en-US", {
    month: "long", day: "numeric", year: "numeric",
  });
  return withRetry(async () => {
    const text = await askClaude(
      `Search the web NOW for today's (${today}) MLB probable pitchers — one search, no preamble, do not write anything before or after the JSON. Your ENTIRE output must be JSON. Shape — one array per game, [awayTeam,awayW,awayL,awaySP,awayERA,homeTeam,homeW,homeL,homeSP,homeERA]:
{"g":[["Cubs",59,45,"Taillon",5.38,"Pirates",53,52,"Ashcraft",3.95]]}
Short club names; W/L = records before today; if starter unannounced use "TBD" and null. Every game today. No spaces after commas. JSON only.`
    );
    const parsed = parseJsonLoose(text);
    const rows = (parsed.g || []).filter((r) => Array.isArray(r) && r.length === 10);
    if (!rows.length) throw new Error("Empty slate returned");
    return rows.map((r) => ({
      away: { team: r[0], fullName: r[0], w: r[1], l: r[2], sp: r[3], rate: r[4], spIp: null, penIp3: null },
      home: { team: r[5], fullName: r[5], w: r[6], l: r[7], sp: r[8], rate: r[9], spIp: null, penIp3: null },
    }));
  });
}

async function fetchBullpens() {
  // Hosted deployments: serverless proxy holds the API key (see api/bullpens.js).
  try {
    const r = await fetch("/api/bullpens");
    if (r.ok) {
      const parsed = await r.json();
      const entries = Object.entries(parsed).filter(
        ([, v]) => typeof v === "number" && v > 1 && v < 9
      );
      if (entries.length >= 24) return Object.fromEntries(entries);
    }
  } catch {}
  // claude.ai artifact: direct call works without a key.
  return withRetry(async () => {
    const text = await askClaude(
      `Search the web NOW for current MLB team bullpen ERA, all 30 teams (covers.com team bullpen ERA statistics has them) — one search, no preamble, nothing before or after the JSON. Output must be JSON only: {"Brewers":3.48,"Red Sox":3.07} style, short club name to season bullpen ERA, all 30 teams, no spaces. JSON only.`
    );
    const parsed = parseJsonLoose(text);
    const entries = Object.entries(parsed).filter(
      ([, v]) => typeof v === "number" && v > 1 && v < 9
    );
    if (entries.length < 24) throw new Error("Incomplete bullpen data");
    return Object.fromEntries(entries);
  }, 2);
}

// ——— UI ———

const C = {
  field: "#123425",
  monster: "#1D4B34",
  panel: "#0E2A1D",
  chalk: "#F2EFE6",
  chalkDim: "rgba(242,239,230,0.55)",
  gold: "#E8B644",
  stitch: "#C6423C",
  line: "rgba(242,239,230,0.16)",
};

function PickCard({ r, rank }) {
  const pct = (r.prob * 100).toFixed(1);
  return (
    <div
      className="relative flex flex-col rounded-lg overflow-hidden"
      style={{
        background: C.monster,
        border: `1px solid ${C.line}`,
        boxShadow: "0 8px 24px rgba(0,0,0,0.35)",
      }}
    >
      <div
        className="absolute top-0 left-0 px-3 py-1 text-sm tracking-widest"
        style={{
          background: rank === 1 ? C.gold : "rgba(242,239,230,0.12)",
          color: rank === 1 ? C.panel : C.chalk,
          fontFamily: "'Bebas Neue', sans-serif",
          borderBottomRightRadius: 8,
        }}
      >
        PICK {rank}
      </div>
      {r.anyTBD && (
        <div
          className="absolute top-0 right-0 px-3 py-1 text-xs tracking-widest"
          style={{
            background: C.stitch, color: C.chalk,
            fontFamily: "'Bebas Neue', sans-serif",
            borderBottomLeftRadius: 8,
          }}
        >
          SP TBD
        </div>
      )}
      <div className="px-4 pt-9 pb-1 text-center">
        <div
          className="text-2xl leading-none"
          style={{ fontFamily: "'Bebas Neue', sans-serif", color: C.chalk, letterSpacing: "0.04em" }}
        >
          {r.pick.team}
        </div>
        <div className="mt-1 text-xs uppercase tracking-widest" style={{ color: C.chalkDim }}>
          {r.pickIsHome ? "vs" : "at"} {r.opp.team}
        </div>
      </div>
      <div className="text-center py-2 pb-4">
        <span
          className="inline-block px-4 py-1 rounded"
          style={{
            fontFamily: "'Bebas Neue', sans-serif",
            fontSize: "3.4rem",
            lineHeight: 1,
            color: C.gold,
            background: C.panel,
            border: `1px solid ${C.line}`,
            letterSpacing: "0.03em",
          }}
        >
          {pct}
          <span style={{ fontSize: "1.4rem", color: C.chalkDim }}>%</span>
        </span>
        <div
          className="mt-2 text-xs px-2"
          style={{ color: C.chalkDim, fontFamily: "'IBM Plex Mono', monospace" }}
        >
          {r.pick.rate != null ? `${r.pick.sp} ${r.pick.rate.toFixed(2)}` : "SP TBD"}
          {" v "}
          {r.opp.rate != null ? `${r.opp.sp} ${r.opp.rate.toFixed(2)}` : "SP TBD"}
        </div>
        {(r.pick.penIp3 != null || r.opp.penIp3 != null) && (
          <div
            className="mt-1 text-xs px-2"
            style={{ color: C.chalkDim, fontFamily: "'IBM Plex Mono', monospace" }}
          >
            pen 3d: {r.pick.penIp3 != null ? r.pick.penIp3.toFixed(0) : "–"}
            {" / "}
            {r.opp.penIp3 != null ? r.opp.penIp3.toFixed(0) : "–"} IP
          </div>
        )}
      </div>
    </div>
  );
}

export default function BensBaby() {
  const [slate, setSlate] = useState(null);
  const [status, setStatus] = useState("loading");
  const [errMsg, setErrMsg] = useState("");
  const [lastChecked, setLastChecked] = useState(null);
  const [source, setSource] = useState("");
  const bpRef = useRef(FALLBACK_BULLPEN);
  const rawGames = useRef(null);
  const timer = useRef(null);

  const rank = (games) =>
    games.map((g) => predictGame(g, bpRef.current)).sort((a, b) => b.prob - a.prob);

  const load = useCallback(async () => {
    setStatus((s) => (s === "ok" ? "ok" : "loading"));
    try {
      let games, src;
      try {
        games = await fetchSlateStatsApi();
        src = "MLB StatsAPI · FIP + IP/start";
      } catch {
        games = await fetchSlateClaude();
        src = "web search · ERA, default IP (StatsAPI unavailable in this sandbox)";
      }
      // fatigue: best-effort, non-blocking
      fetchFatigue(games)
        .then((totals) => {
          if (!rawGames.current) return;
          for (const g of rawGames.current)
            for (const s of ["home", "away"])
              if (totals[g[s].fullName] != null)
                g[s].penIp3 = totals[g[s].fullName];
          setSlate(rank(rawGames.current));
          setSource((v) => v + " · pen fatigue live");
        })
        .catch(() => {});
      rawGames.current = games;
      setSlate(rank(games));
      setSource(src);
      setLastChecked(new Date());
      setStatus("ok");
    } catch (e) {
      setErrMsg(String(e.message || e));
      setStatus((s) => (s === "ok" ? "ok" : "error"));
      setLastChecked(new Date());
    }
  }, []);

  useEffect(() => {
    fetchBullpens()
      .then((map) => {
        bpRef.current = map;
        if (rawGames.current) setSlate(rank(rawGames.current));
      })
      .catch(() => {});
    load();
    timer.current = setInterval(load, POLL_MINUTES * 60 * 1000);
    return () => clearInterval(timer.current);
  }, [load]);

  const top = slate ? slate.slice(0, N_PICKS) : [];
  const tbdInTop = top.some((g) => g.anyTBD);

  return (
    <div className="min-h-screen w-full" style={{ background: C.field, color: C.chalk }}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=IBM+Plex+Mono:wght@400;500&display=swap');
        @media (prefers-reduced-motion: reduce) { * { animation: none !important; transition: none !important; } }
        .bb-spin { animation: bbspin 1.2s linear infinite; } @keyframes bbspin { to { transform: rotate(360deg); } }`}</style>

      <header className="max-w-6xl mx-auto px-4 pt-10 pb-6 text-center">
        <div
          className="inline-block px-8 py-2"
          style={{
            background: C.stitch,
            color: C.chalk,
            fontFamily: "'Bebas Neue', sans-serif",
            fontSize: "2.6rem",
            letterSpacing: "0.12em",
            clipPath: "polygon(0 0, 100% 0, 94% 50%, 100% 100%, 0 100%, 6% 50%)",
          }}
        >
          BEN&#39;S BABY
        </div>
        <div
          className="mt-3 text-xs uppercase tracking-widest"
          style={{ color: C.chalkDim, fontFamily: "'IBM Plex Mono', monospace" }}
        >
          today&#39;s five strongest picks ·{" "}
          {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" })}
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 pb-16">
        {status === "loading" && !slate && (
          <div className="text-center py-24" style={{ fontFamily: "'IBM Plex Mono', monospace" }}>
            <div
              className="bb-spin inline-block w-10 h-10 rounded-full mb-4"
              style={{ border: `3px solid ${C.line}`, borderTopColor: C.gold }}
            />
            <div style={{ color: C.chalkDim }}>Checking today&#39;s starters…</div>
          </div>
        )}

        {status === "error" && !slate && (
          <div
            className="max-w-md mx-auto text-center p-6 rounded-lg"
            style={{ background: C.monster, border: `1px solid ${C.line}`, fontFamily: "'IBM Plex Mono', monospace" }}
          >
            <div className="text-sm mb-2" style={{ color: C.chalk }}>
              Couldn&#39;t load today&#39;s picks.
            </div>
            <div className="text-xs mb-4" style={{ color: C.chalkDim }}>{errMsg}</div>
            <button
              onClick={load}
              className="px-4 py-2 rounded"
              style={{ background: C.gold, color: C.panel, border: "none", cursor: "pointer" }}
            >
              Try again
            </button>
          </div>
        )}

        {slate && (
          <>
            {tbdInTop && (
              <div
                className="text-center text-xs mb-4"
                style={{ color: C.gold, fontFamily: "'IBM Plex Mono', monospace" }}
              >
                Some starters not announced yet — picks are provisional and will
                update on their own.
              </div>
            )}
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
              {top.map((r, i) => (
                <PickCard key={`${r.pick.team}-${r.opp.team}`} r={r} rank={i + 1} />
              ))}
            </div>

            <footer
              className="mt-10 text-center text-xs leading-relaxed"
              style={{ color: C.chalkDim, fontFamily: "'IBM Plex Mono', monospace" }}
            >
              {source && `${source} · `}
              {lastChecked &&
                `checked ${lastChecked.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })} · re-checks every ${POLL_MINUTES} min · `}
              <button
                onClick={load}
                style={{
                  background: "none", border: "none", color: C.chalk,
                  textDecoration: "underline", cursor: "pointer", padding: 0,
                  font: "inherit",
                }}
              >
                refresh now
              </button>
              <br />
              Model v3: regressed win% · log5 · home field · starter FIP × expected IP ·
              bullpen ERA + 3-day fatigue, in log-odds.
              <br />
              Model output, not betting advice — a 60% pick loses two nights in five.
            </footer>
          </>
        )}
      </main>
    </div>
  );
}
